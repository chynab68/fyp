# creating urls: 

#from django.contrib import admin

from django.urls import path, include 
from . import views




#from .views import getBooks

urlpatterns = [
    #specifying paths: 
    path('', views.landingPage, name = "storyBridge_landingPage"),
    path('home/', views.home, name = "storyBridge_home"),

    path('login/', views.login_user, name= 'storyBridge_login'),
    path('logout/', views.logout_user, name= 'storyBridge_logout'),

    path('signUp/', views.signUp, name= 'storyBridge_signup'),
    path('signUpSuccess/', views.signUpSuccess, name= 'storyBridge_signupcomplete'),


    path('profile/', views.profile, name= 'storyBridge_profile'),
    path('editProfile/', views.editProfile, name= 'storyBridge_editProfile'),
    path('accountSettings/', views.accountSettings, name= 'storyBridge_accountSettings'),

    path('books/', views.myBooks, name='storyBridge_myBooks'),
    path('books/currentlyReading/', views.currentlyReading, name='storyBridge_currentlyReading'),
    path('books/wantToRead/', views.wantToRead, name='storyBridge_wantToRead'),
    path('books/read/', views.read, name='storyBridge_read'),

    path('search-books/', views.searchBooks, name='storyBridge_searchBooks'), #api call
    path('search-results/', views.searchResults, name='storyBridge_searchResults'),

    path('browse/', views.explore, name='storyBridge_explore'),
    path('browse/<str:genre>/', views.browseByGenre, name='storyBridge_genreBrowse'),

    path('books/<str:book_key>/', views.displayBookDetails, name='storyBridge_bookDetails'), #for book details 

    path('goals/', views.goals, name='storyBridge_goals'),
    path('badges/', views.badges, name='storyBridge_badges'),
    
    
 

]