from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth import login

#handling logic for api endpoints: 
#from rest_framework.decorators import api_view
# from rest_framework.response import Response 
# from rest_framework import status
# from .models import Books, Genres, Authors
#from .serializer import BookSerializer, GenreSerializer, AuthorSerializer


#from .forms import RegistrationForm


def landingPage(request):
    return render(request, 'storyBridge/landingpage.html')

def home(request):
    return render(request, 'storyBridge/homePage.html')

def login(request):
    if request.method == "POST":
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            #login here!
            
            return render(request, 'StoryBridge/homePage.html' ) 
    
    else: #get request-
        form = AuthenticationForm()

    return render(request, 'storyBridge/login.html', {"form": form} )


def signUp(request):
    #sign up form attempt 2:
    if request.method == "POST": #means if form has been submitted then..
        form = UserCreationForm(request.POST)
        #if form is valid: 
        if form.is_valid():
            # login(request, form.save()) #this logs user in once theyve registetered.
            user = form.save(commit=False)
            user.save()
            # return redirect('signUpSuccess' )
            return render(request, 'StoryBridge/registrationSuccess.html' ) 

    else:
        form = UserCreationForm()
    return render(request, 'storyBridge/signUpPage.html', {"form": form} ) 


def signUpSuccess(request):
    return render(request, 'StoryBridge/registrationSuccess.html' )  


# views for profile section:
def profile(request):
    return render(request, 'StoryBridge/profileSection/profilePage.html')

def editProfile(request):
    return render(request, 'StoryBridge/profileSection/editProfile.html')

def accountSettings(request):
    return render(request, 'StoryBridge/profileSection/accountSettings.html')

#views for books sections:
def myBooks(request):
    return render(request, 'storyBridge/books/myBooks.html')

def currentlyReading(request):
    return render(request, 'storyBridge/books/currentlyReading.html')

def wantToRead(request):
    return render(request, 'storyBridge/books/wantToRead.html')

def read(request):
    return render(request, 'storyBridge/books/read.html')


#views for explore section:
def explore(request):
    return render(request, 'storyBridge/explore/explorePage.html') 

#fiction books: 
def romance(request):
    return render(request, 'storyBridge/explore/romance.html') 

def fantasy(request):
    return render(request, 'storyBridge/explore/fantasy.html')

def sciFi(request):
    return render(request, 'storyBridge/explore/sciFi.html') 

def youngAdult(request):
    return render(request, 'storyBridge/explore/youngAdult.html')

def thriller(request):
    return render(request, 'storyBridge/explore/thriller.html')  

def horror(request):
    return render(request, 'storyBridge/explore/horror.html')

def mystery(request):
    return render(request, 'storyBridge/explore/mystery.html')

def adventure(request):
    return render(request, 'storyBridge/explore/adventure.html')

#non-fiction books: 
def biographies(request):
    return render(request, 'storyBridge/explore/biographies.html')

def politics(request):
    return render(request, 'storyBridge/explore/politics.html')

def science(request):
    return render(request, 'storyBridge/explore/science.html')

def travel(request):
    return render(request, 'storyBridge/explore/travel.html')

#views for goals & badges: 
def goals(request):
    return render(request, 'storyBridge/goals.html' )

def badges(request):
    return render(request,'storyBridge/badges.html' )

  
#defining endpoints: 

#practice one!!!!
# @api_view(['GET'])
# def getBooks(request):
#     serializer = BookSerializer(data = {'bookTitle': "TFIOS", 'bookDescription': "vv sad ending" ,'author': "someone", 'isbn': "1622662rrt25"})
#     serializer.is_valid()
#     return Response(serializer.data)
    # return Response(BookSerializer({'bookTitle': "TFIOS", 'bookDescription': "vv sad ending" ,'author': "someone", 'isbn': "1622662rrt25"}).data) 