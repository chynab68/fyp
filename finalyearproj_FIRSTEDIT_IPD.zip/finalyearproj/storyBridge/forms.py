#this is going to be the user registration section (using django built in registration)

from django import forms 
from django.contrib.auth.forms import UserCreationForm
# from django.contrib.auth.models import User



# class RegistrationForm(UserCreationForm):
#     Email = forms.EmailField(required=True)

#     class Meta:
#         Model = User 
#         Fields = ['username', 'email', 'password1', 'password2']
        # Fields = ['firstName', 'lastName', 'email', 'password1', 'password2']