from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm, UserChangeForm
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages
from django.contrib.auth.models import User
from django import forms
from .forms import SignUpForm, UpdateUserForm
import requests
from django.http import JsonResponse
import time
from datetime import datetime 

#handling logic for api endpoints: 
#from rest_framework.decorators import api_view
# from rest_framework.response import Response 
# from rest_framework import status
# from .models import Books, Genres, Authors
#from .serializer import BookSerializer, GenreSerializer, AuthorSerializer


#from .forms import RegistrationForm


def landingPage(request):
    return render(request, 'storyBridge/landingpage.html')

def home(request):
    return render(request, 'storyBridge/homePage.html')

#THIS WORKS, BUT TRYING A DIFF APPROACH
# def login(request):
#     if request.method == "POST":
#         form = AuthenticationForm(data=request.POST)
#         if form.is_valid():
#             #login here!
            
#             return render(request, 'StoryBridge/homePage.html' ) 
    
#     else: #get request-
#         form = AuthenticationForm()

#     return render(request, 'storyBridge/login.html', {"form": form} )

def login_user(request):
    
    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)

        #check its the right username/password combo: 
        if user is not None:
            login(request, user)
            messages.success(request, ("You have been logged in"))
            return redirect('storyBridge_home')
        #if not successful-
        else: 
            messages.success(request, ("There's been an error, please try again "))
            return redirect('storyBridge_login')

    else:
       return render(request, 'storyBridge/login.html') 



def logout_user(request):
    logout(request)
    messages.success(request, ("You have been logged out"))
    return redirect('storyBridge_home')


def signUp(request):
    form = SignUpForm()

    # are they filling out form?  
    if request.method == "POST":
        form = SignUpForm(request.POST) #takes all stuff user inputs into form & put it into signupform 
        #is this valid? 
        if form.is_valid():
            form.save()
            username = form.cleaned_data['username']
            password = form.cleaned_data['password1']

            #log user in:
            user = authenticate(username=username, password=password)
            login(request, user)
            return redirect('storyBridge_home')
        
        else: 
            messages.success(request, ("There's been an error with your sign up, please try again! "))
            return redirect('storyBridge_signup')

    else:
        return render(request, 'storyBridge/signUpPage.html', {'form':form})

#this works, but trying a diff method-
# def signUp(request):
#     #sign up form attempt 2:
#     if request.method == "POST": #means if form has been submitted then..
#         form = UserCreationForm(request.POST)
#         #if form is valid: 
#         if form.is_valid():
#             # login(request, form.save()) #this logs user in once theyve registetered.
#             user = form.save(commit=False)
#             user.save()
#             # return redirect('signUpSuccess' )
#             return render(request, 'StoryBridge/registrationSuccess.html' ) 

#     else:
#         form = UserCreationForm()
#     return render(request, 'storyBridge/signUpPage.html', {"form": form} ) 


def signUpSuccess(request):
    return render(request, 'StoryBridge/registrationSuccess.html' )  


# views for profile section:
def profile(request):
    return render(request, 'StoryBridge/profileSection/profilePage.html')


def editProfile(request):
    if request.user.is_authenticated:
        #look up user id in user model 
        currentUser = User.objects.get(id=request.user.id)

        userForm = UpdateUserForm(request.POST or None, instance=currentUser) #when user goes to profile page, it will already have their info in the form

        if userForm.is_valid():
            userForm.save() #once info has been updated, log them back in w that updated info 
            login(request, currentUser)
            messages.success(request, "User has been updated!")
            return redirect('storyBridge_home')
    
        return render(request, 'StoryBridge/profileSection/editProfile.html', {'userForm': userForm}) 
    
    #if not logged in:
    else:
        messages.success(request, "You must be logged in to access this page ")
        return redirect('storyBridge_home')


def accountSettings(request):
    return render(request, 'StoryBridge/profileSection/accountSettings.html')



#views for books sections:
def myBooks(request):
    return render(request, 'storyBridge/books/myBooks.html')

def currentlyReading(request):
    return render(request, 'storyBridge/books/currentlyReading.html')

def wantToRead(request):
    return render(request, 'storyBridge/books/wantToRead.html')

def read(request):
    return render(request, 'storyBridge/books/read.html')


#this fetches data from open library and allows users to search for books based on title, author, subject- API CALL
def searchBooks(request):
    query = request.GET.get('query', '').strip() #this is the search term 

    if not query:
        return JsonResponse({"error": "no query provided"}, status=400)
    
    #make request to open library api to search for books: 
    url = f"https://openlibrary.org/search.json?q={query}"
    response = requests.get(url)

    if response.status_code == 200: #if request has been processed properly 
        booksData = response.json()
        books = booksData.get('docs', [])

        #debugging by printing api response: 
        print("Raw API Response: ", booksData)
        print("Extracted books: ", books)

        if not books:
            return JsonResponse([], safe=False) #return an empty list if no books are found 


        bookInfo = []
        for book in books[:10]: #limits results to 10 items 
            title = book.get('title', 'No Title')
            author_name = book.get('author_name', ['Unknown Author'])[0]
            first_publish_year = book.get('first_publish_year', 'N/A')
            cover_id = book.get('cover_i', None)
            cover_url = f"http://covers.openlibrary.org/b/id/{cover_id}-L.jpg" if cover_id else ''

            bookInfo.append({
                'title': title,
                'author': author_name,
                'first_publish_year': first_publish_year,
                'cover_url': cover_url,
                'openlibrary_url': f"https://openlibrary.org{book.get('key', '')}"
            })

        #print("Final Book info: ", bookInfo ) #debug
        return render(request, 'storyBridge/explore/searchResults.html', {'books': bookInfo, 'query': query})
        # return JsonResponse(bookInfo, safe=False)
    return JsonResponse({"error": "Failed to fetch data from Open Library API"}, status=500)

def searchResults(request):
    query = request.GET.get('query', '').strip()
    print(f"Received query: {query}") #debug 
    
    if not query:
        return render(request, 'storyBridge/explore/searchResults.html', {'books': [], 'query': query}) 
    
    url = f"https://openlibrary.org/search.json?q={query}"
    response = requests.get(url)

    if response.status_code == 200: 
        booksData = response.json()
        books = booksData.get('docs', [])

        bookInfo = []
        for book in books[:10]:
            title = book.get('title', 'No Title')
            author_name = book.get('author_name', ['Unknown Author'])[0]
            first_publish_year = book.get('first_publish_year', 'N/A')
            cover_id = book.get('cover_i', None)
            cover_url = f"http://covers.openlibrary.org/b/id/{cover_id}-L.jpg" if cover_id else ''

            #bookKey = book.get('key', '').lstrip('/') #NEWLY ADDED
            bookKey = book.get('key', '')

            bookInfo.append({
                'title': title,
                'author': author_name,
                'first_publish_year': first_publish_year,
                'cover_url': cover_url,
                'openlibrary_url': f"https://openlibrary.org{book.get('key', '')}",

                'book_key': bookKey,
            })
        print(f"Final Book Info: {bookInfo}") #debugging 
        return render(request, 'storyBridge/explore/searchResults.html', {'books': bookInfo, 'query': query})
    
    return render(request, 'storyBridge/explore/searchResults.html', {'books': [], 'query': query})


#views for explore section:
def explore(request): 
    return render(request, 'storyBridge/explore/explorePage.html') 

def browseByGenre(request, genre): #passes in genre from open library 'genre' 
    url = f"https://openlibrary.org/subjects/{genre}.json" 
    response = requests.get(url)

    if response.status_code == 200:
        booksData = response.json()
        books = booksData.get('works', [])

        bookInfo = []
        for book in books[:10]: #limit results being shown
            title = book.get('title', 'No Title')
            author = book.get('authors', [{'name': 'Unknown author'}])[0]['name']
            cover_id = book.get('cover_id') or book.get('cover_i') #trying to get image to show 

            #bookKey = book.get('key', '').lstrip('/') #NEWLY ADDED

            bookKey = book.get('key', '')
            print(f"Extracted book key: {bookKey}") #debugging!

            cover_url = f"http://covers.openlibrary.org/b/id/{cover_id}-L.jpg" if cover_id else ''
            book_url = f"https://openlibrary.org{book.get('key', '')}"

            bookInfo.append({
                'title': title,
                'author': author,
                'cover_url': cover_url,
                'book_url': book_url,

                'book_key': bookKey, #this matches url parameter 
                #'bookKey': bookKey,
            })

        return render(request, 'storyBridge/explore/browseByGenre.html', {'books': bookInfo, 'genre': genre})


    return render(request, 'storyBridge/explore/browseByGenre.html', {'books': [], 'genre': genre})


#view to show details when book is clicked on:
def displayBookDetails(request, book_key): #passes in book_key from open library 

    if not book_key.startswith("/works/"):
        book_key = f"/works/{book_key}"

    url = f"https://openlibrary.org{book_key}.json" 

    print(f"Fetching: {url}") #debugging to see the url being requested 

    response = requests.get(url)

    print(f"Response status code: {response.status_code}") 

    #if request works: 
    if response.status_code == 200:
        bookData = response.json()

        print(f"Book data: {bookData}") #debugging: print api response

        #extracting relevant details open library: 

        #title extraction:
        title = bookData.get('title', 'No Title')
        
        #extracting author data (rather than just (unknown author appearing) 
        authors = []
        if 'authors' in bookData:

            print("Authors field exists in bookDate: ", bookData['authors']) #debugging statement 

            for author_entry in bookData['authors']:
                #author_key = author_entry.get('key', '')

                author_key = author_entry.get('author', {}).get('key')

                if author_key:  # Ensure author_key is not empty
                    author_url = f"https://openlibrary.org{author_key}.json"  # Correct API URL

                    print(f"fetching author details from: {author_url}") #debug 

                    #having issues w timeout, so adding retries and increasing timeout
                    retries = 3
                    for attempt in range (retries):
                    
                        try:
                            author_response = requests.get(author_url, timeout=15)  
                            author_response.raise_for_status()  # Raise HTTP errors

                            author_data = author_response.json()
                            print("Author data response: ", author_data) #debug 

                            author_name = author_data.get('name', 'Unknown Author')
                            authors.append(author_name)
                            break #stop if successful 
                        
                        except requests.exceptions.Timeout:
                            print(f"Timeout error on attempt number: {attempt + 1}. Retrying...")
                            time.sleep(2) #wait before retry 

                        except requests.exceptions.RequestException as e:
                            print(f"Failed to fetch author details: {e}")
                            break #stop if another error occurs 

                    else:
                        authors.append('Unknown author')  

        # If no authors were found, use "Unknown Author"
        if not authors:
            print("no authors found in api response, setting to 'unknown author' ") #debug 
            authors = ['Unknown Author']

        #decription extraction
        description = bookData.get('description', {}).get('value', 'No description available') if isinstance(bookData.get('description', {}), dict) else bookData.get('description', 'No description available')
        
        
        #publishDate extraction
        #year of release: 
        publish_date = bookData.get('created', {}).get('value', 'N/A')

        try:
            publish_year = datetime.strptime(publish_date, "%Y-%m-%dT%H:%M:%S.%f").year if publish_date != 'N/A' else 'N/A'
        except ValueError:
            publish_year = 'N/A' #deals w unexpected date formats 

        #this works, but displays the entire date/timestamp, i just want the year of release to be shown!
        # publishDate = 'N/A'
        # if 'first_publish_year' in bookData:
        #     publishDate = bookData['first_publish_date']
        # elif 'created' in bookData:
        #     publishDate = bookData['created'].get('value', 'N/A')
        # elif 'publish_date' in bookData:
        #     publishDate = bookData['publish_date']


        #cover id/url extraction
        cover_id = bookData.get('covers', [None])[0]
        cover_url = f"http://covers.openlibrary.org/b/id/{cover_id}-L.jpg" if cover_id else ''

        #storing extracted data: 
        bookInfo = {
            'title': title,
            'authors': authors,
            'description': description,
            'publish_date': publish_year,
            #'publish_date': publishDate,
            'cover_url': cover_url,
        }
        return render(request, 'storyBridge/explore/bookDetails.html' , {'book': bookInfo})
    
    print("book not found :(") #debug 
    return render(request, 'storyBridge/explore/bookDetails.html' , {'book': None, 'error': 'Book not found!'})



#views for goals & badges: 
def goals(request):
    return render(request, 'storyBridge/goals.html' )

def badges(request):
    return render(request,'storyBridge/badges.html' )

  
#defining endpoints: 

#practice one!!!!
# @api_view(['GET'])
# def getBooks(request):
#     serializer = BookSerializer(data = {'bookTitle': "TFIOS", 'bookDescription': "vv sad ending" ,'author': "someone", 'isbn': "1622662rrt25"})
#     serializer.is_valid()
#     return Response(serializer.data)
    # return Response(BookSerializer({'bookTitle': "TFIOS", 'bookDescription': "vv sad ending" ,'author': "someone", 'isbn': "1622662rrt25"}).data) 