# creating urls: 

#from django.contrib import admin

from django.urls import path, include 
from . import views




#from .views import getBooks

urlpatterns = [
    #specifying paths: 
    path('', views.landingPage, name = "storyBridge_landingPage"),
    path('home/', views.home, name = "storyBridge_home"),

    path('login/', views.login_user, name= 'storyBridge_login'),
    path('logout/', views.logout_user, name= 'storyBridge_logout'),

    path('signUp/', views.signUp, name= 'storyBridge_signup'),
    path('signUpSuccess/', views.signUpSuccess, name= 'storyBridge_signupcomplete'),


    path('profile/', views.profile, name= 'storyBridge_profile'),
    path('editProfile/', views.editProfile, name= 'storyBridge_editProfile'),
    path('accountSettings/', views.accountSettings, name= 'storyBridge_accountSettings'),

    path('books/', views.myBooks, name='storyBridge_myBooks'),
    path('books/currentlyReading/', views.currentlyReading, name='storyBridge_currentlyReading'),
    path('books/wantToRead/', views.wantToRead, name='storyBridge_wantToRead'),
    path('books/read/', views.read, name='storyBridge_read'),

    path('explore/', views.explore, name='storyBridge_explore'),

    path('search-books/', views.searchBooks, name='storyBridge_searchBooks'), #api call
    path('search-results/', views.searchResults, name='storyBridge_searchResults'),

    path('explore/romance/', views.romance, name='storyBridge_romance'),
    path('explore/fantasy/', views.fantasy, name='storyBridge_fantasy'),
    path('explore/scienceFiction/', views.sciFi, name='storyBridge_sciFi'),
    path('explore/youngAdult/', views.youngAdult, name='storyBridge_youngAdult'),
    path('explore/thriller/', views.thriller, name='storyBridge_thriller'),
    path('explore/horror/', views.horror, name='storyBridge_horror'),
    path('explore/mystery/', views.mystery, name='storyBridge_mystery'),
    path('explore/adventure/', views.adventure, name='storyBridge_adventure'),
    
    path('explore/biographies/', views.biographies, name='storyBridge_biographies'),
    path('explore/politics/', views.politics, name='storyBridge_politics'),
    path('explore/science/', views.science, name='storyBridge_science'),
    path('explore/travel/', views.travel, name='storyBridge_travel'),

    path('goals/', views.goals, name='storyBridge_goals'),
    path('badges/', views.badges, name='storyBridge_badges'),
    
    
    
    #api routes: 
    #path('books/', getBooks, name='getBooks')

]