from django.db import models

# # Create your models here.

#class for custom usrs (which I'll implement later- for jnow login/registration uses built in user)
class CustomUser(models.Model):
    userName = models.CharField(max_length=150)
    fName = models.CharField(max_length=50)
    lName = models.CharField(max_length=150)
    email = models.EmailField(unique=True)

    def __str__(self):
        return self.userName

#class for authors:
class Authors(models.Model):
    authorName = models.CharField(max_length=255)
    authorBiography = models.TextField(blank=True)

    # def __str__(self):
    #     return self.authorName

       

#class for books: 
class Books(models.Model):
    bookTitle = models.CharField(max_length=500)
    genre = models.ManyToManyField("Genres")
    bookDescription = models.TextField(blank=False)
    isbn = models.CharField(max_length=13, unique=True, null=True, blank=True)
    author = models.ForeignKey("Authors", on_delete=models.CASCADE) 
    user = models.ForeignKey('auth.User', on_delete=models.CASCADE) #may want to change this later (when change to customer user!)
    #bookshelf = models.ForeignKey("Bookshelf", on_delete=models.CASCADE)

    # def __str__(self):
    #     return self.bookTitle
    

#class for genres: 
class Genres(models.Model):
    genreName = models.CharField(max_length=200, unique=True)
    description = models.TextField(blank=True, null=True)
    book = models.ForeignKey(Books, on_delete=models.CASCADE)

    # def __str__(self):
    #     return self.genreName #displays egnre name in admin 


#model for bookshelves: 
class Bookshelfs(models.Model):
    book = models.ForeignKey(Books, on_delete=models.CASCADE)
    user = models.ForeignKey('auth.User', on_delete=models.CASCADE)
    dateAddedToShelf = models.DateTimeField(auto_now_add=True)

    CURRENTLY_READING = "CR"
    WANT_TO_READ = "WTR"
    READ = "RD"
    BOOKSELF_TYPE = {
        CURRENTLY_READING: "CurrentlyReading",
        WANT_TO_READ: "WantToRead",
        READ: "Read",
    }
    bookshelfType = models.CharField(max_length=20, choices=BOOKSELF_TYPE)


#model for badges: 
class Badges(models.Model):
    badgeName = models.CharField(max_length=200, unique=True)
    badgeDescription = models.TextField(blank=True, null=True)
    user = models.ForeignKey('auth.User', on_delete=models.CASCADE)

    def __str__(self):
        return self.badgeName




#model for reviews: 
class Reviews(models.Model):
    reviewText = models.TextField(blank=True, null=True)
    rating = models.DecimalField(max_digits=3, decimal_places=1, null=True, blank=True)
    user = models.ForeignKey('auth.User', on_delete=models.CASCADE)  
    book = models.ForeignKey(Books, on_delete=models.CASCADE)

    # def __str__(self):
    #     return self.

#model for followers: 
class Followers(models.Model):
    user = models.ForeignKey('auth.User', on_delete=models.CASCADE)
    author = models.ForeignKey("Authors", on_delete=models.CASCADE)
    # def __str__(self):
    #     return self.

#link table betweebn badges and users:
class Badge_Obtained_By_User(models.Model):
    user = models.ForeignKey('auth.User', on_delete=models.CASCADE)
    badge = models.ForeignKey("Badges", on_delete=models.CASCADE)

#link table between user & book: 
class User_Reads_Book(models.Model):
    user = models.ForeignKey('auth.User', on_delete=models.CASCADE)
    book = models.ForeignKey(Books, on_delete=models.CASCADE)
    readingStartDate = models.DateTimeField(auto_now_add=True)