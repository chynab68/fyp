from django.contrib import admin
from .models import Authors, Books, Genres, Bookshelfs, Badges, Reviews, Followers, Badge_Obtained_By_User, User_Reads_Book
# Register your models here.


admin.site.register(Authors)
admin.site.register(Books)
admin.site.register(Genres)
admin.site.register(Bookshelfs)
admin.site.register(Badges)
admin.site.register(Reviews)
admin.site.register(Followers)
admin.site.register(Badge_Obtained_By_User)
admin.site.register(User_Reads_Book)